<?php
return array(
    'ACCEPT' => 'ACCEPT'
);