<?php
return array(
    "NAME" => '备份名称',
    "FILE_SIZE" => '文件大小',
    "BACKUP_TIME" => '备份时间',
    "SELECT_ALL" => '选择全部 ',
    "START_BACKUP" => '开始备份数据',
    "BACKUP_TYPE" => '备份类型 ',
    "VOLUME_SIZE" => '每个分卷文件大小 ',
    "VOLUME_SIZE_HELP_TEXT" => '推荐10M以下',
    "CUSTOM_BACKUP" => '自定义备份',
    "BACKUP_ALL" => '全部备份'
);