<?php
return array(
    'ACCEPT' => '接 受'
);